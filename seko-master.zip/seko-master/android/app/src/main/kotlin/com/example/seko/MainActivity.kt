package com.example.seko

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
