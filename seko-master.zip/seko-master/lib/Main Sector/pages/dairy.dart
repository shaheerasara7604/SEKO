import 'package:flutter/material.dart';

class Dairy extends StatelessWidget {
  const Dairy({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
